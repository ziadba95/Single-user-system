public class Test {

    public static void main(String[] args) {


        Adapter adapter = new Adapter("members.bin", "instructors.bin", "classes.bin");
        MemberList tempList = new MemberList();

        Member m0 = new Member("Ivonne Sampson","236 Lantern Street", "246988","email@email.com","Basic");
        Member m1 = new Member("Claribel Mckim","636 Pumpkin Hill St.", "457895","email@email.com","Basic");
        Member m2 = new Member("Dario Vath","746 William Dr. ", "55186259","email@email.com","Premium");
        Member m3 = new Member("Adrianna Edick","9393 Garden Drive ", "7789224","email@email.com","Basic");
        Member m4 = new Member("Shalonda Jump","8608 Cemetery Street ", "761555","email@email.com","Premium");
        Member m5 = new Member("Jonie Lush","508 Old Chestnut Street ", "5756156","email@email.com","Premium");
        Member m6 = new Member("Luise Ritacco","153 Evergreen St. ", "47521452","email@email.com","Basic");
        Member m7 = new Member("Vina Braz","8036 Old Kirkland St.", "558752","email@email.com","Premium");
        Member m8 = new Member("Rubie Ottinger","72 Bay St.", "4856156","email@email.com","Premium");
        Member m9 = new Member("Le Hannum","7695 E. Goldfield Ave.", "54514563","email@email.com","Basic");
        Member m10 = new Member("Minh Windley","51 2nd Ave. ", "762586156","email@email.com","Basic");
        Member m11 = new Member("Dominique Bodiford","709 Griffin St. ", "55752146","email@email.com","Basic");
        Member m12 = new Member("Elna Bowling","33 Edgewater Ave. ", "7546625","email@email.com","Basic");
        Member m13 = new Member("Maryann Emmerich","7854 Military Street", "5787515","email@email.com","Basic");
        Member m14 = new Member("Brooke Frye","87 Glendale Lane", "57521566","email@email.com","Basic");
        Member m15 = new Member("Latrisha Mccay","8729 Trout St. ", "55745212","email@email.com","Premium");
        Member m16 = new Member("Jule Maddy","903 2nd St.", "5156348","email@email.com","Premium");
        Member m17 = new Member("Harry Gazaway","750 Randall Mill Drive", "455841556","email@email.com","Premium");
        Member m18 = new Member("Jennie Keesee","8338 Clinton St. ", "8752156","email@email.com","Premium");
        Member m19 = new Member("Antonio Farrow","840 Bellevue Street ", "554588","email@email.com","Basic");
        Member m20 = new Member("Huey Moos","99 Golden Star St.", "57752166","email@email.com","Basic");
        Member m21 = new Member("Maurice Scholl","29 Newport Drive ", "86456652","email@email.com","Basic");
        Member m22 = new Member("Nathaniel Stabler","476 Courtland Lane ", "71223656","email@email.com","Basic");
        Member m23 = new Member("Nohemi Norcross","9749 Chapel St. ", "75123545","email@email.com","Basic");
        Member m24 = new Member("Shanice Humfeld","476 Courtland Lane ", "5245215","email@email.com","Premium");
        Member m25 = new Member("Rima Retana","35 Hanover St. ", "752463456","email@email.com","Premium");
        Member m26 = new Member("Jolyn Dedman","59 Garden Dr. ", "54822335","email@email.com","Premium");
        Member m27 = new Member("Rubi Iverson\n","53 Van Dyke Circle", "5515621","email@email.com","Premium");
        Member m28 = new Member("Laquanda Haar","32 South Halifax Rd. ", "5556455","email@email.com","Premium");
        Member m29 = new Member("Siu Hatchett","68 Rocky River St.", "23654636","email@email.com","Premium");
        Member m30 = new Member("Carl Sherwin","826 Laurel Lane ", "5648532","email@email.com","Premium");

        tempList.addMember(m0);
        tempList.addMember(m1);
        tempList.addMember(m2);
        tempList.addMember(m3);
        tempList.addMember(m4);
        tempList.addMember(m5);
        tempList.addMember(m6);
        tempList.addMember(m7);
        tempList.addMember(m8);
        tempList.addMember(m9);
        tempList.addMember(m10);
        tempList.addMember(m11);
        tempList.addMember(m12);
        tempList.addMember(m13);
        tempList.addMember(m14);
        tempList.addMember(m15);
        tempList.addMember(m16);
        tempList.addMember(m17);
        tempList.addMember(m18);
        tempList.addMember(m19);
        tempList.addMember(m20);
        tempList.addMember(m21);
        tempList.addMember(m22);
        tempList.addMember(m23);
        tempList.addMember(m24);
        tempList.addMember(m25);
        tempList.addMember(m26);
        tempList.addMember(m27);
        tempList.addMember(m28);
        tempList.addMember(m29);
        tempList.addMember(m30);





            adapter.saveMembers(tempList);
        }

    }
